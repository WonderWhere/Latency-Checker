# Latency Checker

Latency monitoring for macOS, Windows and Linux, split into two programs:

| | What it does | Needs |
|---|---|---|
| **Logger** (`latency_logger.py`) | Headless. Pings your targets and the current local gateway, looks up the public IP, and appends everything to daily CSV logs. Can run as a service that starts at boot. | Python 3.9+ only, no extra packages |
| **Viewer** (`latency_viewer.py`) | The window: live and historical graphs, stats, targets and settings. It doesn't ping anything; it reads the logs and follows today's file live. | Python + Tkinter + matplotlib |

On one machine both share `~/LatencyChecker/`. They can also run on different machines; see *Several locations* below.

- `config.json` holds the targets and settings. The viewer edits it, and the logger re-reads it within one round.
- `logs/latency_YYYY-MM-DD.csv` holds the measurements.
- `status.json` is the logger's heartbeat, so the viewer knows whether the logger is running.
- `logger.log` is the logger's own diagnostic log: start and stop, config reloads, gateway and public-IP changes, errors.

## 1. Set up the logger as a service (starts at boot, runs headless)

**macOS:** double-click `install_service_mac.command` (first time: right-click → Open) and enter your Mac password.
Or in Terminal: `sudo python3 latency_logger.py install`.

- It installs a launchd **LaunchDaemon** (`/Library/LaunchDaemons/com.latencychecker.logger.plist`). It starts when the Mac boots, even before anyone logs in, and runs as *your* user so the logs belong to you. launchd restarts it if it ever stops.
- The logger is copied to `~/LatencyChecker/app/` and runs from there. macOS doesn't let boot-time services read `~/Documents`, so the service never depends on this project folder. **Run the installer again after updating the code.**

**Windows:** double-click `install_service_windows.bat` and accept the administrator prompt.
Or from an admin prompt: `py -3 latency_logger.py install`.

- It registers a **scheduled task** "LatencyChecker Logger". The task runs at system startup as SYSTEM (headless, before anyone logs in), with no time limit, and restarts every minute if it stops. It keeps writing to your `C:\Users\<you>\LatencyChecker` folder.
- As on macOS, the logger is copied to `LatencyChecker\app\`, so run the installer again after updating the code.

**Start at login instead of boot (no admin rights):** `python3 latency_logger.py install --at-login`.

**Check it:** `python3 latency_logger.py status` shows whether the service is installed, whether the logger is running, the last heartbeat, gateway and public IP.
**Remove it:** `uninstall_service_mac.command` / `uninstall_service_windows.bat`, or `latency_logger.py uninstall`.
**Linux (systemd):** run `./install_service_linux.sh`, which asks for sudo. Or run `sudo python3 latency_logger.py install`.

- It installs a system service, `/etc/systemd/system/latency-logger.service`. It starts at every boot, before anyone logs in, and runs as *your* user so the logs belong to you. `Restart=always` brings it back if it stops.
- The logger is copied to `~/LatencyChecker/app/`, so run the installer again after updating the code.
- **Without root:** `./install_service_linux.sh --at-login` installs a per-user service in `~/.config/systemd/user/` that runs while you're logged in. To keep it running when you're logged out and start it at boot, also run `sudo loginctl enable-linger $USER` once.
- **Day-to-day:** `python3 latency_logger.py status`, `sudo python3 latency_logger.py restart` (drop `sudo` for the user service), `journalctl -u latency-logger`, or `~/LatencyChecker/logger.log`.
- **Remove it:** `./uninstall_service_linux.sh`.
- **Requirements:** Python 3.9+ and `ping`; on Debian/Ubuntu, `sudo apt install iputils-ping` if it's missing. The logger needs no Python packages. It reads the gateway straight from `/proc/net/route`, so the `ip` tool isn't required either.
- **Other init systems:** without systemd, start `python3 latency_logger.py run --quiet` from your init system or an `@reboot` cron entry.

Only one logger runs at a time. If the service starts while you're running one by hand, it waits and takes over when that one stops.

## 2. Open the viewer

1. Install Python 3.9+ from python.org (includes Tkinter). Homebrew Python users: `brew install python-tk`.
2. Open it without any terminal window:
   - **macOS:** double-click **Latency Checker.app** in this folder. You can drag it to the Dock, but keep the app itself in this folder. The first time, right-click → Open, and allow access to the Documents folder if macOS asks.
   - **Windows:** double-click **Latency Checker (Windows).vbs**. You can make a shortcut to it on the desktop or in the Start menu.
   - **Linux:** run `./run_linux.sh`, or `./install_desktop_linux.sh` once to add *Latency Checker* to your applications menu. Needs Tkinter: `sudo apt install python3-tk python3-venv` (Debian/Ubuntu), `sudo dnf install python3-tkinter` (Fedora) or `sudo pacman -S tk` (Arch).
   - `run_mac.command` and `run_windows.bat` still work too. The Terminal window now closes by itself once the viewer is open.

   On first run it creates a local `.venv` with matplotlib, the Sun Valley theme and dark-mode detection. That takes about a minute, and a notification tells you it's happening. Launch problems are written to `~/LatencyChecker/viewer-launch.log`.

The header shows whether the logger is running, and whether it runs as a service. It also shows the current gateway and public IP. If the logger isn't running, **Start logger** launches it in the background. That instance keeps going after you close the viewer, but it won't start at boot; use the service for that. You can also run it by hand in a terminal: `python3 latency_logger.py` (Ctrl+C stops it).

## Using the viewer

- Add a target (IP or hostname, optional name) and press **Add**. Select one or more rows and press **Remove** to drop them. The logger picks up the change on its next round.
- **Settings** (left panel): ping interval, timeout, the gateway and public-IP switches, and the log folder. These are all logger settings, saved to `config.json`.
- The ☀/☾ button switches between light and dark. By default the viewer follows your system's appearance.
- Timeouts show as small ticks along the bottom of the graph and count toward Loss.
- **Log scale** (toggle in the toolbar) switches the vertical axis to logarithmic (0.5 · 1 · 2 · 5 · 10 · 20 · 50 · 100 … ms). The gateway at ~1 ms, internet targets at 10–30 ms and occasional 800 ms spikes then all stay readable together, and nothing is clipped. The choice is remembered.

### Local gateway (auto-detected)

With **Auto-detect local gateway** ticked, the first row is always your current network's default gateway. It is re-detected every round, so when you switch Wi-Fi / Ethernet / hotspot it follows automatically:

- The row shows the gateway IP and interface, e.g. `192.168.1.1 (en0)`.
- The status bar announces the change, and the graph draws a dashed vertical line labelled with the new gateway IP (or "offline").
- The gateway keeps one continuous line on the graph across networks; each log row stores the actual IP it pinged, with `role = gateway`.
- VPN/tunnel interfaces (utun, tun, wg, ppp…) are skipped on macOS/Linux so you get the *local* router. On Windows the active default route with the lowest metric is used. Some VPNs take over that route, and then the VPN's gateway is shown instead.

### Public IP

With **Record public IP** switched on (Settings), every log row also stores your public (internet-facing) IPv4 address, so you can tell which connection or ISP a measurement came from.

- The app looks it up every 5 minutes and right after a network change. It asks a plain-text "what is my IP" service (api.ipify.org, with ifconfig.me, icanhazip.com and checkip.amazonaws.com as fallbacks). These services see your IP, as any website would.
- After a network switch the column stays blank until the new IP is confirmed, so an old IP is never logged against the new network.
- The header shows the current public IP, and the status bar tells you when it changes.

### Naming your networks

**Settings › Networks…** lists every public IP and local gateway found in your logs, with first- and last-seen dates. You can also double-click the Local gateway row in the table to open it.

- Select an address, type a name (e.g. "Lisbon home – fibre", "Office", "Phone hotspot") and press **Save name** or Enter.
- **Look up ISP** suggests a name for a public IP, such as "MEO · Lisbon, PT". It asks ipinfo.io, and only when you click it.
- Names appear in the header, the gateway row and its legend entry, the dashed network-change markers on the graph, and status messages. That includes past data, because names are applied when the logs are displayed rather than written into them.
- When the viewer sees a public IP you haven't named yet, the status bar reminds you to name it.
- Names are stored under `"names"` in `config.json`.
- Local gateway addresses like 192.168.1.1 are shared by many routers, so a gateway name applies everywhere that address appears. Public IPs identify a network more reliably.

### Navigating history

- **Span buttons**: 15m · 1h · 6h · 12h · 24h · 7d · 30d.
- **Custom…** lets you pick any From/To range, with shortcuts for Today, Yesterday, This week and This month.
- **Drag across the graph** to zoom into exactly that span. **Double-click** zooms out.
- **‹ / ›** move one span back or forward, and **Live** returns to now.
- Up to 1 hour you see every sample. Longer spans show averages so the graph stays readable, sized to about 360 points: 1 min buckets for 6 h, 2 min for 12 h, 5 min for 24 h, 30 min for 7 d and 2 h for 30 d. The line is the average and the shaded band is the min–max; ticks mark buckets with ≥ 2 % loss.
- The stats table always covers the range on screen.
- Past days are read from the CSV logs. A 1-minute summary of each finished day is cached in `logs/.summary/`, so week and month views load quickly after the first time. The cache rebuilds itself if a log file changes, and you can delete it safely.

## Files

- Logs: `~/LatencyChecker/logs/latency_YYYY-MM-DD.csv` (one per day). Columns: `timestamp, host, label, latency_ms, status, role, public_ip` (`role` is `gateway` or `target`). Today's file from an older version gets the new header automatically, and your rows are kept. Change the folder with **Change log folder…**.
- Settings, targets, span and theme: `~/LatencyChecker/config.json` (shared by the logger and the viewer). Set `"theme"` to `"system"`, `"dark"` or `"light"`.

## Several locations (remote loggers)

Run a logger at each place you want to measure from, e.g. the Lisbon house and the Andorra home. One viewer can then show any of them, or compare them side by side.

**On each remote logger machine (once):**

```
python3 latency_logger.py remote enable --name "Andorra Home"      # add --bind <address> to limit it
python3 latency_logger.py pair                                     # prints address, one-time code, fingerprint
```

**In the viewer:** open **Location › Add location…**, enter the address and the code, and press **Connect**. Check that the fingerprint matches the one `pair` printed, then press **Fingerprint matches — Pair**.

- **Location picker** (header): choose *This computer* or any paired location. Each entry shows whether it's online, offline or its logger is stopped. Targets, settings, network names, stats and graphs all follow the selected location. Changes you make are sent to that logger, unless the location was paired with `pair --read-only`.
- **Compare locations:** pick one target, e.g. Cloudflare DNS or the local gateway, to get one line per location on a single time axis. It shows whether a slowdown is local or everywhere.
- **Offline:** each location's history is copied into `~/LatencyChecker/remote-cache/`. Finished days are copied once and today's file is followed incrementally, so you can still browse a location while it's unreachable.
- **Time zones:** a location's graphs use that location's local time, and the range line says so. Compare mode puts everything on this computer's clock.
- **Manage locations…:** rename, re-pair or remove a location. Removing deletes its cache; also run `latency_logger.py remote revoke <id>` on the logger.

**Security:**

- TLS 1.2+ on every connection. The logger's self-signed certificate is pinned by fingerprint on first contact, like SSH, so an impostor is refused.
- Each viewer has its own random 256-bit key, obtained through a single-use pairing code that expires after 10 minutes. The logger stores only a hash of each key.
- Roles: *full access* or *read-only*.
- Failed logins and pairing attempts are rate-limited per address, and pairings, config changes and rejected requests appear in `logger.log`.
- A remote viewer can't change where logs are stored, and every target it sends is validated.
- The viewer keeps its keys in `~/LatencyChecker/viewer.json`, readable only by you.
- Across the internet, use a VPN such as Tailscale or WireGuard and `--bind` to its address, rather than opening a port on your router.

**Logger commands:**

- `remote status`: shows whether it's listening, the addresses, the fingerprint and how many viewers are paired.
- `remote clients`: lists the paired viewers.
- `remote revoke <id|name>`: removes one viewer.
- `remote disable`: stops remote access.

Creating the certificate uses `openssl`, which is built into macOS and Linux, or the `cryptography` package (`pip install cryptography`, the easiest route on Windows).

## Log compression

Finished daily logs are compressed automatically to `latency_YYYY-MM-DD.csv.gz`. They typically shrink to about a tenth of their size; in testing, 13.4 MB became 1.2 MB. Today's file stays plain `.csv` while it's being written.

- **When:** the logger compresses when it starts, and again shortly after every midnight. It runs in the background, so pings aren't delayed.
- **Now:** `python3 latency_logger.py archive` (safe while the service runs, no restart needed), or **Compress old logs** in the viewer's Settings.
- **Restart the service:** `sudo python3 latency_logger.py restart` (macOS) or `latency_logger.py restart` from an admin prompt (Windows). It compresses again as it starts.
- **Reading:** the viewer reads `.csv.gz` directly; nothing is unpacked to disk. To look at one yourself, double-click it (macOS Archive Utility and Windows 11 Explorer both open `.gz`), or use `gunzip -k file.csv.gz`.
- **Safety:** a day's file is claimed first (renamed to `.part`), compressed to a temp file, decompressed again and line-counted, and only then swapped in. A file another program has open (e.g. in Excel on Windows) is skipped and retried next time. After a crash, leftover `.part` files are picked up on the next run.
- **Settings** in `config.json`: `"compress_logs": false` turns it off. `"compress_after_days": 2` also keeps yesterday uncompressed.

## Build standalone apps (no Python needed on the target machine)

- **macOS:** `./build_mac.sh` → `dist/Latency Checker.app` (viewer) and `dist/LatencyLogger` (logger). Install the service with `sudo dist/LatencyLogger install`.
- **Windows:** `build_windows.bat` → `dist\LatencyChecker.exe` and `dist\LatencyLogger.exe`. Install the service from an admin prompt with `LatencyLogger.exe install`.
- **Both at once:** push this folder to a GitHub repo; `.github/workflows/build.yml` builds everything and attaches it as workflow artifacts.

Keep `LatencyLogger` next to the viewer so **Start logger** can find it. PyInstaller can't cross-compile, so each build runs on its own OS. The builds are unsigned: on macOS, right-click → Open the first time; on Windows, SmartScreen may ask you to confirm with "More info → Run anyway".

## Troubleshooting

- **Viewer says "Logger not running":** run `latency_logger.py status`, then look at `~/LatencyChecker/logger.log` (and `logger.stdout.log` on macOS) for errors.
- **macOS: the gateway always times out while internet targets work:** macOS 15+ may block local-network access. Allow **Python** (or LatencyLogger) under System Settings › Privacy & Security › Local Network.
- **You updated the code:** run the service installer again so the copy in `~/LatencyChecker/app/` is refreshed.
